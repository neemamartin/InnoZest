package com.example.innozest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Discussion extends AppCompatActivity {

    FloatingActionButton addpartcipantbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discussion);
        addpartcipantbtn=findViewById(R.id.add_participant);
        addpartcipantbtn.setOnClickListener((v)-> startActivity(new Intent(Discussion.this,addpart.class)));
    }
}