package com.example.innozest;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.Notification;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView username= (TextView) findViewById(R.id.username);
        TextView password= (TextView) findViewById(R.id.password);

        MaterialButton loginbtn= (MaterialButton) findViewById(R.id.loginbtn);
        //welcome and hello
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(username.getText().toString().equals("welcome")&& password.getText().toString().equals("hello"))
                {
                    //correct
                    Toast.makeText(MainActivity.this,"Login Successful!",Toast.LENGTH_SHORT).show();
                    switchActivities();
                }
                else
                {
                    //incorrect
                    Toast.makeText(MainActivity.this,"Login unsuccessful!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void twitter(View view)
    {
        String url="https://twitter.com/i/flow/login";
        Intent a=new Intent(Intent.ACTION_VIEW);
        a.setData(Uri.parse(url));
        startActivity(a);
    }

    public void facebook(View view)
    {
        String url="https://www.facebook.com/login/";
        Intent b=new Intent(Intent.ACTION_VIEW);
        b.setData(Uri.parse(url));
        startActivity(b);
    }

    public void Google(View view)
    {
        String url="https://accounts.google.com/ServiceLogin?elo=1";
        Intent c=new Intent(Intent.ACTION_VIEW);
        c.setData(Uri.parse(url));
        startActivity(c);
    }

    public void switchActivities() {
        Intent switchActivityIntent = new Intent(this, Discussion.class);
        startActivity(switchActivityIntent);
    }
}