package com.example.innozest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;

public class addpart extends AppCompatActivity {

    EditText titleEditText,contentEditText;
    ImageButton savethreadbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addpart);

        titleEditText=findViewById(R.id.threadtitle);
        contentEditText=findViewById(R.id.threadcontent);
        savethreadbtn=findViewById(R.id.savethreadbtn);

        savethreadbtn.setOnClickListener((v)->savethread());
    }
    void savethread()
    {
        String thrdtitle=titleEditText.getText().toString();
        String thrdcont=contentEditText.getText().toString();
        if(thrdtitle==null || thrdtitle.isEmpty())
        {
            titleEditText.setError("Title is required!");
            return;
        }
    }
}